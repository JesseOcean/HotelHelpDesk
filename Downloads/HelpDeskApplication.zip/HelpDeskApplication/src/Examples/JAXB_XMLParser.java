package Examples;

// Note: The xsd schema viewer (in Eclipse) might report errors if you try to view your schemas with an 
// active internet connection, if so: view (and edit) your xml schemas offline please 

// This class uses the JAXB library to automatically read a xml file and 
// generate objects containing this data from pre-compiled classes

// Remember to generate the classes first from your xml schema and import them into your project which  
// might require a 'refresh' of your project directory (context menu > refresh)

// Generate the classes automatically with: Opening a command console and type:
// Path to YOUR-PROJECTROOT-IN-WORKSPACE\xjc.bat yourschemaname.xsd -d src -p yourclasspackagename


import java.io.*;
import javax.xml.bind.*;

//This is a candidate for a name change because you wont deal with a library any more in your conversion
import Examples.Library;

public class JAXB_XMLParser {

	private JAXBContext jaxbContext = null;     // generate a context to work in with JAXB											   
	private Unmarshaller unmarshaller = null;   // unmarshall = generate objects from an xml file												
	
	private Hotel myNewHotel = null;            // the main object containing all data

	public JAXB_XMLParser() {

		try {
			jaxbContext = JAXBContext.newInstance("Examples");  // Package that contains ouer classes																													
			unmarshaller = jaxbContext.createUnmarshaller();
		}
		catch (JAXBException e) {
		}
	}
	
	// Instance objects and return a list with this objects in it
	public Hotel loadXML(InputStream fileinputstream) {

		try {
			Object xmltoobject = unmarshaller.unmarshal(fileinputstream);

			if (myNewHotel == null) {

				//generate the myNewHotel object that contains all info from the xml document
				myNewHotel = (Hotel) (((JAXBElement) xmltoobject).getValue());	
				
				return myNewHotel; // return Hotel Objekt
			}
		} // try

		catch (JAXBException e) {
			e.printStackTrace();
		}
		return null;
	}
}
